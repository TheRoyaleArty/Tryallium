package net.mcreator.machinetryallium.procedure;

import net.mcreator.machinetryallium.ElementsMachinetryallium;

@ElementsMachinetryallium.ModElement.Tag
public class ProcedureUnclaim extends ElementsMachinetryallium.ModElement {
	public ProcedureUnclaim(ElementsMachinetryallium instance) {
		super(instance, 99);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		double tileentity = 0;
		tileentity = (double) 1;
	}
}
