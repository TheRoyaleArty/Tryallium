
package net.mcreator.machinetryallium.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.machinetryallium.item.ItemAzuriteIngot;
import net.mcreator.machinetryallium.block.BlockAzuriteOre;
import net.mcreator.machinetryallium.ElementsMachinetryallium;

@ElementsMachinetryallium.ModElement.Tag
public class RecipeAzuriteOreSmelting extends ElementsMachinetryallium.ModElement {
	public RecipeAzuriteOreSmelting(ElementsMachinetryallium instance) {
		super(instance, 44);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(BlockAzuriteOre.block, (int) (1)), new ItemStack(ItemAzuriteIngot.block, (int) (1)), 0.7F);
	}
}
