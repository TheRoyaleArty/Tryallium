
package net.mcreator.machinetryallium.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.machinetryallium.item.ItemTaaffeitIngot;
import net.mcreator.machinetryallium.block.BlockTaaffeitOre;
import net.mcreator.machinetryallium.ElementsMachinetryallium;

@ElementsMachinetryallium.ModElement.Tag
public class RecipeTaaffeitOreSmelting extends ElementsMachinetryallium.ModElement {
	public RecipeTaaffeitOreSmelting(ElementsMachinetryallium instance) {
		super(instance, 34);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(BlockTaaffeitOre.block, (int) (1)), new ItemStack(ItemTaaffeitIngot.block, (int) (1)), 0.7F);
	}
}
