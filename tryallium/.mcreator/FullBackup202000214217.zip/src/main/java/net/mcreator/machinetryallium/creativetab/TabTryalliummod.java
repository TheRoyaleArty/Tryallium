
package net.mcreator.machinetryallium.creativetab;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

import net.minecraft.item.ItemStack;
import net.minecraft.creativetab.CreativeTabs;

import net.mcreator.machinetryallium.item.ItemTryalliumGem;
import net.mcreator.machinetryallium.ElementsMachinetryallium;

@ElementsMachinetryallium.ModElement.Tag
public class TabTryalliummod extends ElementsMachinetryallium.ModElement {
	public TabTryalliummod(ElementsMachinetryallium instance) {
		super(instance, 96);
	}

	@Override
	public void initElements() {
		tab = new CreativeTabs("tabtryalliummod") {
			@SideOnly(Side.CLIENT)
			@Override
			public ItemStack getTabIconItem() {
				return new ItemStack(ItemTryalliumGem.block, (int) (1));
			}

			@SideOnly(Side.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundImageName("item_search.png");
	}
	public static CreativeTabs tab;
}
