
package net.mcreator.machinetryallium.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.machinetryallium.item.ItemTryalliumGem;
import net.mcreator.machinetryallium.block.BlockTryalliumOre;
import net.mcreator.machinetryallium.ElementsMachinetryallium;

@ElementsMachinetryallium.ModElement.Tag
public class RecipeTryalliumOreSmelting extends ElementsMachinetryallium.ModElement {
	public RecipeTryalliumOreSmelting(ElementsMachinetryallium instance) {
		super(instance, 19);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(BlockTryalliumOre.block, (int) (1)), new ItemStack(ItemTryalliumGem.block, (int) (1)), 0.7F);
	}
}
