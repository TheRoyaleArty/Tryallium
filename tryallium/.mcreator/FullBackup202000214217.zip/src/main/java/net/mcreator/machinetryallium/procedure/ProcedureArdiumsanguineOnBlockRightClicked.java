package net.mcreator.machinetryallium.procedure;

import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;

import net.mcreator.machinetryallium.gui.GuiArdiumsanguine;
import net.mcreator.machinetryallium.Machinetryallium;
import net.mcreator.machinetryallium.ElementsMachinetryallium;

@ElementsMachinetryallium.ModElement.Tag
public class ProcedureArdiumsanguineOnBlockRightClicked extends ElementsMachinetryallium.ModElement {
	public ProcedureArdiumsanguineOnBlockRightClicked(ElementsMachinetryallium instance) {
		super(instance, 176);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure ArdiumsanguineOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure ArdiumsanguineOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure ArdiumsanguineOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure ArdiumsanguineOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure ArdiumsanguineOnBlockRightClicked!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).openGui(Machinetryallium.instance, GuiArdiumsanguine.GUIID, world, x, y, z);
	}
}
