package net.mcreator.machinetryallium.procedure;

import net.mcreator.machinetryallium.ElementsMachinetryallium;

@ElementsMachinetryallium.ModElement.Tag
public class ProcedureTryalliumBootsTickEvent extends ElementsMachinetryallium.ModElement {
	public ProcedureTryalliumBootsTickEvent(ElementsMachinetryallium instance) {
		super(instance, 134);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
	}
}
